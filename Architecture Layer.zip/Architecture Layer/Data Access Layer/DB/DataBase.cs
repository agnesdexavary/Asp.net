﻿
//  Data Access Layer  // 

//  Its for handling database interaction like reading, writing, updating and deleting records using entity framework.

//  Its used  to pass parameters from database.


using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace MyApp.DataAccessLayer
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}

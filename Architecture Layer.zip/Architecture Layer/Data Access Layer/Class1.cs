﻿namespace Data_Access_Layer
{
    public class Class1
    {

    }
}

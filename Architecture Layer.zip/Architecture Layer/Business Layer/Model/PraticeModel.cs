﻿
//   Business Logic Layer   //

//   Its responsible for handling business rules and validation and processing in a application. It acts as a bridgt b/w 
//   presentation layer and data access layer.

//   Model  //

//   It structures the data in an application , its responsible for holding , validating and transfering data b/w 
//   different layers.


public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}


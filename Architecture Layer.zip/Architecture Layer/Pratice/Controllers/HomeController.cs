﻿

//  Presentation Layer  //

//  Presentation layer is used for the user inter face and interaction with the application. 


// Controller //

// A Controller is used for HTTP request, processing data and returning response. Its a intermediate B/w presentation layer
// and business layer.


using Microsoft.AspNetCore.Mvc;
using MyApp.BusinessLayer.Services;

namespace MyApp.PresentationLayer.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        public IActionResult Index()
        {
            var products = _productService.GetAllProducts();
            return View(products);
        }
    }
}


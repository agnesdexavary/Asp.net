﻿using SolidPrinciples.Interfaces;

namespace SolidPrinciples.Services
{
    public class EmailNotificationService : INotificationService
    {
        public void Notify(string message)
        {
            Console.WriteLine($"Email Notification Sent: {message}");
        }
    }
}


﻿using SolidPrinciples.Interfaces;
using SolidPrinciples.Models;

namespace SolidPrinciples.Services
{
    public class OrderProcessor : IOrderProcessor
    {
        private readonly INotificationService _notificationService;

        public OrderProcessor(INotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        public void ProcessOrder(Order order)
        {
            Console.WriteLine($"Processing Order: {order.OrderId} - {order.ProductName} (Qty: {order.Quantity})");

            _notificationService.Notify($"Order {order.OrderId} has been processed successfully.");
        }
    }
}           

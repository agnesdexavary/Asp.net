﻿using SolidPrinciples.Models;
  

namespace SolidPrinciples.Interfaces
{
    public interface IOrderProcessor
    {
        void ProcessOrder(Order order);
    }
}

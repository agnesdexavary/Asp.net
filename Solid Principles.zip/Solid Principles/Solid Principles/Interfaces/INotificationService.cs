﻿namespace SolidPrinciples.Interfaces
{
    public interface INotificationService
    {
        void Notify(string message);
    }
}


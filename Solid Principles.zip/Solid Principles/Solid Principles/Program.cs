using SolidPrinciples.Interfaces;
using SolidPrinciples.Models;
using SolidPrinciples.Services;

namespace SolidPrinciples
{
    class Program
    {
        static void Main(string[] args)
        {
            INotificationService notificationService = new EmailNotificationService();
            IOrderProcessor orderProcessor = new OrderProcessor(notificationService);

            Order order = new Order { OrderId = 1, ProductName = "Laptop", Quantity = 2 };

            orderProcessor.ProcessOrder(order);

            Console.WriteLine("Order processing completed.");
        }
    }
}

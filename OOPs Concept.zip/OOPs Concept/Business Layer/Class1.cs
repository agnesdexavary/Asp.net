﻿namespace Business_Layer
{
    public class Class1
    {

    }
}

﻿using System;
using System.Collections.Generic;

namespace ECommerceApp.Models
{
    public class Order
    {
        private List<string> items = new List<string>(); // Private field
        private decimal totalAmount;

        public void AddItem(string item, decimal price)
        {
            items.Add(item);
            totalAmount += price;
        }

        public decimal GetTotalAmount()
        {
            return totalAmount;
        }

        public List<string> GetItems()
        {
            return new List<string>(items); // Returning a copy to maintain encapsulation
        }
    }
}

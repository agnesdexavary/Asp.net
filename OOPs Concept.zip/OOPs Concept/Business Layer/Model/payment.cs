﻿namespace ECommerceApp.Models
{
    public abstract class Payment
    {
        public abstract void ProcessPayment(decimal amount);
    }
}

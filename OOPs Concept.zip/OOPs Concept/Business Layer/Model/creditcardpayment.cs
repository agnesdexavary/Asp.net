﻿using System;

namespace ECommerceApp.Models
{
    public class CreditCardPayment : Payment
    {
        public override void ProcessPayment(decimal amount)
        {
            Console.WriteLine($"Processing Credit Card Payment of ${amount}");
        }
    }
}

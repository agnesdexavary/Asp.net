﻿using System;

namespace ECommerceApp.Models
{
    public class PayPalPayment : Payment
    {
        public override void ProcessPayment(decimal amount)
        {
            Console.WriteLine($"Processing PayPal Payment of ${amount}");
        }
    }
}


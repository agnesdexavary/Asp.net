﻿using ECommerceApp.Models;

namespace ECommerceApp.Services
{
    public class PaymentProcessor
    {
        public void MakePayment(Payment payment, decimal amount)
        {
            payment.ProcessPayment(amount); // Calls overridden method dynamically
        }
    }
}

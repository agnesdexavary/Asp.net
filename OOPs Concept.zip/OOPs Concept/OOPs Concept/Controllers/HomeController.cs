﻿using Microsoft.AspNetCore.Mvc;

namespace OOPs_Concept.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

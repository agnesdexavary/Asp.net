﻿namespace Data_Acess_Layer
{
    public class Class1
    {

    }
}

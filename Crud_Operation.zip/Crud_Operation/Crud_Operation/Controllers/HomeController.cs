﻿using Crud_Operation.Model;
using Microsoft.AspNetCore.Mvc;
using Crud_Operation.EmployeeData; 

namespace EmployeeApi.Controllers
{
    [ApiController]
    [Route("api/employees")]
    public class EmployeeController : ControllerBase
    {
        private readonly DatabaseHelpers _dbHelper;

        public EmployeeController(DatabaseHelpers dbHelper)
        {
            _dbHelper = dbHelper;
        }

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            var employees = _dbHelper.GetEmployees();
            return Ok(employees);
        }

        [HttpGet("{id}")]
        public IActionResult GetEmployeeById(int id)
        {
            var employee = _dbHelper.GetEmployeeById(id);
            if (employee == null) return NotFound();
            return Ok(employee);
        }

        [HttpPost]
        public IActionResult CreateEmployee([FromBody] Employee employee)
        {
            if (employee == null) return BadRequest();
            _dbHelper.AddEmployee(employee);
            return Ok(new { message = "Employee added successfully" });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateEmployee(int id, [FromBody] Employee employee)
        {
            if (employee == null || id != employee.Id) return BadRequest();
            var existingEmployee = _dbHelper.GetEmployeeById(id);
            if (existingEmployee == null) return NotFound();

            _dbHelper.UpdateEmployee(employee);
            return Ok(new { message = "Employee updated successfully" });
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmployee(int id)
        {
            var existingEmployee = _dbHelper.GetEmployeeById(id);
            if (existingEmployee == null) return NotFound();

            _dbHelper.DeleteEmployee(id);
            return Ok(new { message = "Employee deleted successfully" });
        }
    }
}
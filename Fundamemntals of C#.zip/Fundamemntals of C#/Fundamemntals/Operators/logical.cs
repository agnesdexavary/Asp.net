﻿namespace Fundamemntals.Operators
{

    class Logical
    {
        static void Main()
        {
            bool x = true, y = false;
            Console.WriteLine(x && y); // False
            Console.WriteLine(x || y); // True
            Console.WriteLine(!x);     // False
        }
    }

}

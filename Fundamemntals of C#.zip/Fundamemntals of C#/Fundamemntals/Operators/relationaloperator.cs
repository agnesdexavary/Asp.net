﻿namespace Fundamemntals.Operators
{
    class Relationaloperator
    {
        static void Main()
        {
            int a = 10, b = 5;
            Console.WriteLine(a > b);  // True
            Console.WriteLine(a < b);  // False
            Console.WriteLine(a == b); // False
        }
    }

}

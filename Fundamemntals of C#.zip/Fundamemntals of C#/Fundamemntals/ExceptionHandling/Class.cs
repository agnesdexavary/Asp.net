﻿namespace Fundamemntals.ExceptionHandling
{
    
    class Program
    {
        static void Main()
        {
            try
            {
                int num = int.Parse("ABC");  // This will cause an exception
            }
            catch (FormatException e)
            {
                Console.WriteLine("Invalid input format: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Finally block executed.");
            }
        }
    }

}

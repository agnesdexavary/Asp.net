﻿namespace Fundamemntals.looping_statement
{

    class dowhile
    {
        static void Main()
        {
            int i = 1;

            do
            {
                Console.WriteLine("Iteration: " + i);
                i++;
            } while (i <= 5);
        }
    }

}

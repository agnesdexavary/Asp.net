﻿namespace Fundamemntals.looping_statement
{


    class foreachloop
    {
        static void Main()
        {
            int[] numbers = { 5, 10, 15, 20 };
            int sum = 0;

            foreach (int num in numbers)
            {
                sum += num;
            }

            Console.WriteLine("Sum: " + sum);
        }
    }


}

﻿namespace Fundamemntals.looping_statement
{
    
    class whileloop
    {
        static void Main()
        {
            int i = 1;

            while (i <= 5)
            {
                Console.WriteLine("Iteration: " + i);
                i++;
            }
        }
    }

}

﻿namespace Fundamemntals.looping_statement
{
    
    class Program
    {
        static void Main()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Iteration: " + i);
            }
        }
    }

}

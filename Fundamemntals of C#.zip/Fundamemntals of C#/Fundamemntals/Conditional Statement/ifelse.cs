﻿namespace Fundamemntals.Conditional_Statement
{
   
    class ifelse
    {
        static void Main()
        {
            int number = -5;

            if (number > 0)
            {
                Console.WriteLine("The number is positive.");
            }
            else
            {
                Console.WriteLine("The number is negative or zero.");
            }
        }
    }

}

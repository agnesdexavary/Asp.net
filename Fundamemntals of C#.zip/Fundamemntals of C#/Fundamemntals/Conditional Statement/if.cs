﻿namespace Fundamemntals.Conditional_Statement
{
    class Program
    {
        static void Main()
        {
            int age = 20;
            int salary = 5000;

            if (age > 18 && salary > 3000)
            {
                Console.WriteLine("You are eligible for a credit card.");
            }
        }
    }

}

﻿using System;
using System.Collections.Generic;  

namespace Fundamemntals.list
{
    
    class Program
    {
        static void Main()
        {
            // Create a list of integers
            List<int> numbers = new List<int>();

            // Adding elements
            numbers.Add(10);
            numbers.Add(20);
            numbers.Add(30);

            // Display elements
            Console.WriteLine("List Elements:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }
    }

}

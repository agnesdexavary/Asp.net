﻿namespace Fundamemntals.array
{
    class Program
    {
        static void Main()
        {
            // Declaration and Initialization
            int[] numbers = { 10, 20, 30, 40, 50 };

            // Accessing Elements
            Console.WriteLine("First Element: " + numbers[0]); // Output: 10

            // Looping through Array
            Console.WriteLine("Array Elements:");
            foreach (int num in numbers)
            {
                Console.WriteLine(num);
            }
        }
    }

}

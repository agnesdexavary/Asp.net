﻿namespace Fundamemntals.Interface
{

    interface IShape
    {
        void Draw();  // Method declaration (no implementation)
    }

    // Implementing the interface
    class Circle : IShape
    {
        public void Draw()
        {
            Console.WriteLine("Drawing a Circle");
        }
    }

    class Program
    {
        static void Main()
        {
            IShape shape = new Circle();
            shape.Draw();
        }
    }

}

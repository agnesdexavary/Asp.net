﻿using System;
using System.Threading.Tasks;

namespace Fundamemntals.Async
{

    class Program
    {
        static async Task PrintMessage()
        {
            await Task.Delay(2000);  // Simulates a delay  
            Console.WriteLine("Async method executed.");
        }

        static async Task Main()
        {
            Console.WriteLine("Before async call");
            await PrintMessage();
            Console.WriteLine("After async call");
        }
    }
}

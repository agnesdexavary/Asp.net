﻿namespace Fundamemntals.variablen
{
    class Program
    {
        const double PI = 3.1416;
        static void Main()
        {
            Console.WriteLine(PI);
        }
    }

}

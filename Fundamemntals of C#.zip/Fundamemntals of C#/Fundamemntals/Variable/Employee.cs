﻿namespace Fundamemntals.Implementation
{
    
    class Employee
    {
        public string Name;  // Instance variable
        public int Age;
        public static string Company = "TechCorp"; // Static variable

        public void Display()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}, Company: {Company}");
        }
    }

    class Program
    {
        static void Main()
        {
            Employee emp1 = new Employee();
            emp1.Name = "Alice";
            emp1.Age = 30;
            emp1.Display();

            Employee emp2 = new Employee();
            emp2.Name = "Bob";
            emp2.Age = 28;
            emp2.Display();
        }
    }

}

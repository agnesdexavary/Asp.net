﻿namespace Fundamemntals.variable
{
    class Example
    {
        readonly int id;
        public Example(int x)
        {
            id = x;  // Value can only be assigned here
        }
    }

}

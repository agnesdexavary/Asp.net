﻿namespace Fundamemntals.Variable
{
    class Person
    {
        public string name;  // Instance variable
    }

    class Program
    {
        static void Main()
        {
            Person p1 = new Person();
            p1.name = "Alice";
            Console.WriteLine(p1.name);
        }
    }
}
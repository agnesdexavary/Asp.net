﻿namespace Fundamemntals.variable
{
    class Counter
    {
        public static int count = 0;  // Static variable

        public Counter()
        {
            count++; // Increment count when an object is created
        }

        public void ShowCount()
        {
            Console.WriteLine($"Count: {count}");
        }
    }

    class Program
    {
        static void Main()
        {
            Counter obj1 = new Counter();
            obj1.ShowCount(); // Output: Count: 1

            Counter obj2 = new Counter();
            obj2.ShowCount(); // Output: Count: 2

            Console.WriteLine($"Accessing directly: {Counter.count}"); // Output: Count: 2
        }
    }

}

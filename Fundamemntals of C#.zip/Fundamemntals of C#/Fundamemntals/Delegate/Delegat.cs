﻿namespace Fundamemntals.Delegate
{
  
    class Program
    {
        // Step 1: Declare a delegate  
        delegate void MyDelegate(string message);

        // Step 2: Create a method that matches the delegate signature  
        static void DisplayMessage(string msg)
        {
            Console.WriteLine("Message: " + msg);
        }

        static void Main()
        {
            // Step 3: Create delegate instance and assign method  
            MyDelegate del = DisplayMessage;

            // Step 4: Invoke delegate  
            del("Hello, Delegates!");
        }
    }

}

﻿namespace Fundamemntals.Constructor
{
    class Student
    {
        private string name;
        private int age;

        // Default Constructor
        public Student()
        {
            name = "Unknown";
            age = 18;
        }

        // Parameterized Constructor
        public Student(string studentName, int studentAge)
        {
            name = studentName;
            age = studentAge;
        }

        public void Display()
        {
            Console.WriteLine($"Name: {name}, Age: {age}");
        }
    }

    class Programs
    {
        static void Main()
        {
            Student student1 = new Student();  // Default constructor
            Student student2 = new Student("Alice", 22);  // Parameterized constructor

            student1.Display();
            student2.Display();
        }
    }

}

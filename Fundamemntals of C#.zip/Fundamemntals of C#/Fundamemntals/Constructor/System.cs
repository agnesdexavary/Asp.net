﻿namespace Fundamemntals.Constructor
{
    class Person
    {
        private string name;  // Field

        // Constructor
        public Person()
        {
            name = "John Doe";  // Default value
        }

        public void Display()
        {
            Console.WriteLine($"Name: {name}");
        }
    }

    class Program
    {
        static void Main()
        {
            Person person1 = new Person();  // Constructor is called
            person1.Display();
        }
    }

}

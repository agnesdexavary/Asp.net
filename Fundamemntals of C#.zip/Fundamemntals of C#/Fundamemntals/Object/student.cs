﻿namespace Fundamemntals.Object
{

    class Student
    {
        public string Name;
        public int RollNo;

        // Constructor
        public Student(string name, int rollNo)
        {
            Name = name;
            RollNo = rollNo;
        }

        public void ShowDetails()
        {
            Console.WriteLine($"Student Name: {Name}, Roll Number: {RollNo}");
        }
    }

    class Program
    {
        static void Main()
        {
            // Creating an object using a constructor
            Student student1 = new Student("John", 101);
            student1.ShowDetails();
        }
    }

}

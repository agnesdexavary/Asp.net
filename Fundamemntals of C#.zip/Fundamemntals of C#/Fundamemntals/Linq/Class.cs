﻿using System;
using System.Linq;

namespace Fundamemntals.Linq
{
    class Program
    {
        static void Main()
        {
            int[] numbers = { 2, 5, 8, 10, 15, 20 };

            // Query numbers greater than 5
            var result = from num in numbers
                         where num > 5
                         select num;

            Console.WriteLine("Numbers greater than 5:");
            foreach (var num in result)
            {
                Console.WriteLine(num);
            }
        }
    }

}

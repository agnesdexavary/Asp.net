﻿namespace Fundamemntals.Jump_statement
{

    class returns
    {
        static int Add(int a, int b)
        {
            return a + b;  // Returns the sum of a and b  
        }

        static void Main()
        {
            int result = Add(5, 3);
            Console.WriteLine("Sum: " + result);
        }
    }

}

﻿namespace Fundamemntals.Jump_statement
{
    
    class continues
    {
        static void Main()
        {
            for (int i = 1; i <= 5; i++)
            {
                if (i == 3)
                {
                    Console.WriteLine("Skipping 3");
                    continue;
                }
                Console.WriteLine(i);
            }
        }
    }

}

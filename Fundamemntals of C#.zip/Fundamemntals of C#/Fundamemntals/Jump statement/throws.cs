﻿namespace Fundamemntals.Jump_statement
{

    class throws
    {
        static void ValidateAge(int age)
        {
            if (age < 18)
            {
                throw new ArgumentException("Age must be 18 or older.");
            }

            Console.WriteLine("Valid age.");
        }

        static void Main()
        {
            try
            {
                ValidateAge(16); // This will throw an exception
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: " + ex.Message);
            }
        }
    }

}

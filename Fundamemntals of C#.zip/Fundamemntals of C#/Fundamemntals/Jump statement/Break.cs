﻿namespace Fundamemntals.Jump_statement
{

    class Program
    {
        static void Main()
        {
            for (int i = 1; i <= 10; i++)
            {
                if (i == 5)
                {
                    Console.WriteLine("Loop stops at 5");
                    break;
                }
                Console.WriteLine(i);
            }
        }
    }

}

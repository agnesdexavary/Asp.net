﻿using System;
using System.Collections.Generic;

namespace Fundamemntals.dictionary
{
    
    class Program
    {
        static void Main()
        {
            Dictionary<int, string> employees = new Dictionary<int, string>()
        {
            { 101, "John" },
            { 102, "Emma" },
            { 103, "Michael" }
        };

            Console.WriteLine("Employee List:");
            foreach (var emp in employees)
            {
                Console.WriteLine($"ID: {emp.Key}, Name: {emp.Value}");
            }
        }
    }

}

﻿namespace Fundamemntals.Method
{
    class MathOperations
    {
        public int Multiply(int x, int y)
        {
            return x * y;
        }
    }

    class Operation
    {
        static void Main()
        {
            MathOperations math = new MathOperations();
            int result = math.Multiply(5, 4);
            Console.WriteLine($"Multiplication: {result}");
        }
    }

}

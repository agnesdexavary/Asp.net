﻿namespace Fundamemntals.Method
{
    class Program
    {
        // Method to greet a user
        static void Greet()
        {
            Console.WriteLine("Hello, Welcome to C#!");
        }

        static void Main()
        {
            Greet();  // Calling the method
        }
    }

}

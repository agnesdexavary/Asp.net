﻿namespace Fundamemntals.Class
{
    
    class Employee
    {
        // Fields (private variables)
        private int employeeId;
        private double salary;

        // Properties (Encapsulation: Get and Set)
        public string Name { get; set; }

        // Constructor
        public Employee(int id, string name, double sal)
        {
            employeeId = id;
            Name = name;
            salary = sal;
        }

        // Method to Display Employee Info
        public void DisplayEmployee()
        {
            Console.WriteLine($"ID: {employeeId}, Name: {Name}, Salary: {salary:C}");
        }
    }

    class Program
    {
        static void Main()
        {
            // Creating Objects of Employee Class
            Employee emp1 = new Employee(101, "John Doe", 50000);
            Employee emp2 = new Employee(102, "Alice Smith", 60000);

            // Calling Method
            emp1.DisplayEmployee();
            emp2.DisplayEmployee();
        }
    }

}
